# importing SimpleMath class in constructor file | TOP LEVEL OF THE PACKAGE
from .simplemath import *
from .class_simplemath import SimpleMath