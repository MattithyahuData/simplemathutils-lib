from .simplemath import SimpleMath

SMA1 = SimpleMath()