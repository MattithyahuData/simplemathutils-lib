def addition(x,y):
    ''' Addition function 

        Returns: 
        1st paramter * 2nd parameter  '''

    # Returning sum of 2 values 
    return x+y


def subtraction(x,y):
    ''' Subtraction function 

        Returns: 
        1st paramter - 2nd parameter    
    '''

    # Returning difference between the 1st parameter and 2nd 
    return x-y


def multiplication(x,y):
    ''' Multiplication function 

        Returns: 
        1st paramter * 2nd parameter    
    '''

    # Returning product of 2 values 
    return x-y


def division(x,y):
    ''' Division function 

        Returns: 
        1st paramter / 2nd parameter    
    '''

    # Returning the divion of the 1st parameter by the 2nd 
    return x/y